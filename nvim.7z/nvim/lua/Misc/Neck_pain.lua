require("no-neck-pain").setup({
colors = {
    blend = -0.9,
  text = "#ffffff",
  background = "#2a273f",},
buffers = {
  right = { enabled = true, },
  scratchPad = {
    enabled = true,
    location = "~/Desktop/",
  },
  bo = {
    filetype = "md"
  },
},
})
