vim.cmd.iabbrev({"<buffer>", "#!", "#!/bin/sh"})
